COPY YOUR ANDROID GAME FILES HERE

Required GTA:LCS 2.4.379 files:
- base.apk
- split_config.arm64_v8a.apk
- split_data_main.apk

A complete APKS/APKM/XAPK bundle also works. Launch the port after copying.
For radio music, run ../audio.sh on a computer with your rooted phone attached.

Only use files from your own legally purchased game.
