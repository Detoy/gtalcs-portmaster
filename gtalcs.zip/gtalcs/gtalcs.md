# GTA: Liberty City Stories

## Install

1. Install `gtalcs.zip`.
2. Copy your legally owned Android 2.4.379 files into
   `roms/ports/gtalcs/gamedata/`.
3. Launch the game. The first start extracts the required files.

Use `base.apk`, `split_config.arm64_v8a.apk`, and `split_data_main.apk`, or a
complete APKS/APKM/XAPK bundle containing them.

For the secondary audio/radio pack, run `gtalcs/audio.sh` on a computer
connected to your rooted phone, then launch the port again.

The port contains no Rockstar game files. Saves are stored in
`roms/ports/gtalcs/userdata/`. Original project software is provided under the
MIT License in `gtalcs/licenses/MIT.txt`.
